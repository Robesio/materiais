<?php

	require("../process/process.usuarios.php");

	include("configs.php");

	$up = new UsuariosProcess();

	switch($_SERVER['REQUEST_METHOD']) {
		case "GET":
			$up->doGet($_GET);
			break;

		case "POST":
		    if(!isset($_POST["verbo"])) { //Json
		        $postdata = file_get_contents("php://input");
			    $arr = json_decode($postdata,true);
		    }
		    else // Multipart
		        $arr = $_POST;
	
		    
			$up->doPost($arr);
			break;

		case "PUT":
			$up->doPut($_PUT);
			break;

		case "DELETE":
			$up->doDelete($_DELETE);
			break;
	}